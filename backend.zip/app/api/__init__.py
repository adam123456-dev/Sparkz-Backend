"""API route configuration package."""

